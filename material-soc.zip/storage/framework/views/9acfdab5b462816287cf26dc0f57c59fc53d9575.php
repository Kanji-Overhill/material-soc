

<?php $__env->startSection('content'); ?>
<section class="home-section home-1">
    <div class="container">
            <?php if(!$corporativa->isEmpty()): ?>
            <div class="row">
                <div class="col-12">
                    <h2>Imagen Corporativa</h2>
                </div>
                <?php $__currentLoopData = $corporativa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro_corporativa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <a href="<?php echo e($registro_corporativa->url); ?>" class="registro_id" id="<?php echo e($registro_corporativa->id); ?>" base="<?php echo e(url('img/registros')); ?>/">
                            <div class="content-registro" style="background-image: url(<?php echo e(url('img/registros')); ?>/<?php echo e($registro_corporativa->imagen); ?>);"></div>
                            <p class="text-center">
                                <?php echo e($registro_corporativa->nombre); ?>

                            </p>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
    </div>
</section>
<section class="home-section home-2">
    <div class="container">
            <?php if(!$negocio->isEmpty()): ?>
                <div class="row">
                    <div class="col-12">
                        <h2>Líneas de negocio</h2>
                    </div>
                    <?php $__currentLoopData = $negocio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro_negocio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4">
                            <a href="<?php echo e($registro_negocio->url); ?>" class="registro_id" id="<?php echo e($registro_negocio->id); ?>" base="<?php echo e(url('img/registros')); ?>/">
                                <div class="content-registro" style="background-image: url(<?php echo e(url('img/registros')); ?>/<?php echo e($registro_negocio->imagen); ?>);"></div>
                                <p class="text-center">
                                    <?php echo e($registro_negocio->nombre); ?>

                                </p>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
    </div>
</section>
<section class="home-section home-3">
    <div class="container">
            <?php if(!$herramientas->isEmpty()): ?>
                <div class="row">
                    <div class="col-12">
                        <h2>Herramientas</h2>
                    </div>
                    <?php $__currentLoopData = $herramientas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro_herramientas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4">
                            <a href="<?php echo e($registro_herramientas->url); ?>" class="registro_id" id="<?php echo e($registro_herramientas->id); ?>" base="<?php echo e(url('img/registros')); ?>/">
                                <div class="content-registro" style="background-image: url(<?php echo e(url('img/registros')); ?>/<?php echo e($registro_herramientas->imagen); ?>);"></div>
                                <p class="text-center">
                                    <?php echo e($registro_herramientas->nombre); ?>

                                </p>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
    </div>
</section>
<section class="home-section home-4">
    <div class="container">
            <?php if(!$difusion->isEmpty()): ?>
                <div class="row">
                    <div class="col-12">
                        <h2>Contenido de difusión</h2>
                    </div>
                    <?php $__currentLoopData = $difusion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro_difusion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4">
                            <a href="<?php echo e($registro_difusion->url); ?>" class="registro_id" id="<?php echo e($registro_difusion->id); ?>" base="<?php echo e(url('img/registros')); ?>/">
                                <div class="content-registro" style="background-image: url(<?php echo e(url('img/registros')); ?>/<?php echo e($registro_difusion->imagen); ?>);"></div>
                                <p class="text-center">
                                    <?php echo e($registro_difusion->nombre); ?>

                                </p>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
    </div>
</section>
<section class="home-section home-5">
    <div class="container">
            <?php if(!$eventos->isEmpty()): ?>
                <div class="row">
                    <div class="col-12">
                        <h2>Eventos</h2>
                    </div>
                    <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro_eventos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4">
                            <a href="<?php echo e($registro_eventos->url); ?>" class="registro_id" id="<?php echo e($registro_eventos->id); ?>" base="<?php echo e(url('img/registros')); ?>/">
                                <div class="content-registro" style="background-image: url(<?php echo e(url('img/registros')); ?>/<?php echo e($registro_eventos->imagen); ?>);"></div>
                                <p class="text-center">
                                    <?php echo e($registro_eventos->nombre); ?>

                                </p>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
    </div>
</section>
<section class="registro-section hide">
    <a href="" class="close"><i class="fas fa-times"></i></a>
    <?php if(isset($registros)): ?>
        <img class="image_registro" src="<?php echo e(url('img/registros')); ?>/<?php echo e($registros[0]->imagen); ?>" alt="">
        <h3 class="title"><?php echo e($registros[0]->nombre); ?></h3>
        <p class="description"><?php echo e($registros[0]->descripcion); ?></p>
        <p class="info"><span><?php echo e($count); ?></span> Archivos</p>
        <p class="date">Subido el: <span><?php echo e(date_format($registros[0]->created_at,"Y/m/d")); ?></span></p>
        <a class="download" href="" files="<?php echo e($archivos); ?>" base="<?php echo e(url('archivos')); ?>/"><i class="fas fa-cloud-download-alt"></i></i> Descargar</a>
        <a class="share" href=""><i class="fas fa-share"></i> Compartir</a>
        <a class="copy" href=""><i class="far fa-copy"></i> Copiar vínculo</a>
        <a class="delete" href=""><i class="far fa-trash-alt"></i> Eliminar</a>
    <?php endif; ?>

    <?php if(empty($registros)): ?>
        <img class="image_registro" src="" alt="">
        <h3 class="title"></h3>
        <p class="description"></p>
        <p class="info"><span></span> Archivos</p>
        <p class="date">Subido el: <span></span></p>
        <a class="download" href="" files="[]" base="<?php echo e(url('archivos')); ?>/"><i class="fas fa-cloud-download-alt"></i></i> Descargar</a>
        <a class="share" href=""><i class="fas fa-share"></i> Compartir</a>
        <a class="copy" href=""><i class="far fa-copy"></i> Copiar vínculo</a>
        <a class="delete" href=""><i class="far fa-trash-alt"></i> Eliminar</a>
    <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp-4\htdocs\material-soc\resources\views/home.blade.php ENDPATH**/ ?>